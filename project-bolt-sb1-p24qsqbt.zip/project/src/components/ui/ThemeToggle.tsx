import { Moon, Sun } from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';

export function ThemeToggle() {
  const { isDarkMode, toggleDarkMode } = useAppStore();

  return (
    <button
      onClick={toggleDarkMode}
      className={`p-2 rounded-lg transition-colors ${
        isDarkMode ? 'bg-gray-800 text-white' : 'bg-gray-100 text-gray-800'
      }`}
      aria-label="Toggle theme"
    >
      {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
    </button>
  );
}