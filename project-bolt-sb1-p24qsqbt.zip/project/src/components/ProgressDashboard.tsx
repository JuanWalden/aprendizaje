import React from 'react';
import { useAppStore } from '../store/useAppStore';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Brain, Clock, Target } from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

export function ProgressDashboard() {
  const { progress, flashcards } = useAppStore();

  const chartData = {
    labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'],
    datasets: [
      {
        label: 'Mastery Level',
        data: [0, 20, 35, 45, 60, 75, progress.masteryLevel],
        borderColor: 'rgb(59, 130, 246)',
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
      },
    ],
  };

  const masteredCards = flashcards.filter((card) => card.status === 'mastered').length;
  const masteryPercentage = (masteredCards / flashcards.length) * 100 || 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="flex items-center space-x-3">
            <Brain className="h-8 w-8 text-blue-500" />
            <div>
              <h3 className="text-lg font-semibold">Mastery Level</h3>
              <p className="text-2xl font-bold">{Math.round(masteryPercentage)}%</p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="flex items-center space-x-3">
            <Target className="h-8 w-8 text-green-500" />
            <div>
              <h3 className="text-lg font-semibold">Completed</h3>
              <p className="text-2xl font-bold">
                {progress.flashcardsCompleted + progress.quizzesCompleted}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="flex items-center space-x-3">
            <Clock className="h-8 w-8 text-purple-500" />
            <div>
              <h3 className="text-lg font-semibold">Time Spent</h3>
              <p className="text-2xl font-bold">
                {Math.round(progress.totalTimeSpent / 60)} min
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4">Progress Over Time</h3>
        <div className="h-64">
          <Line
            data={chartData}
            options={{
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  beginAtZero: true,
                  max: 100,
                },
              },
            }}
          />
        </div>
      </div>
    </div>
  );
}