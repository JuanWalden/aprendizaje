import React from 'react';
import { useAppStore } from '../../store/useAppStore';
import { motion } from 'framer-motion';

export function Quiz() {
  const { quizzes, updateQuiz, updateProgress } = useAppStore();
  const [currentIndex, setCurrentIndex] = React.useState(0);
  const [showFeedback, setShowFeedback] = React.useState(false);

  const currentQuiz = quizzes[currentIndex];

  const handleAnswer = (answer: string) => {
    if (!currentQuiz || showFeedback) return;

    updateQuiz(currentQuiz.id, { userAnswer: answer });
    setShowFeedback(true);

    if (answer === currentQuiz.correctAnswer) {
      updateProgress((prev) => ({
        quizzesCompleted: prev.quizzesCompleted + 1,
      }));
    }

    setTimeout(() => {
      setShowFeedback(false);
      setCurrentIndex((prev) => (prev + 1) % quizzes.length);
    }, 2000);
  };

  if (!quizzes.length) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600 dark:text-gray-400">
          No quizzes available. Add some content to generate quizzes!
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-8">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4">{currentQuiz.question}</h3>
          <div className="space-y-3">
            {currentQuiz.options.map((option, index) => (
              <motion.button
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleAnswer(option)}
                className={`w-full p-4 text-left rounded-lg border transition-colors ${
                  showFeedback
                    ? option === currentQuiz.correctAnswer
                      ? 'bg-green-100 border-green-500 dark:bg-green-900 dark:border-green-400'
                      : option === currentQuiz.userAnswer
                      ? 'bg-red-100 border-red-500 dark:bg-red-900 dark:border-red-400'
                      : 'bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700'
                    : 'hover:bg-gray-50 dark:hover:bg-gray-700 border-gray-200 dark:border-gray-700'
                }`}
                disabled={showFeedback}
              >
                {option}
              </motion.button>
            ))}
          </div>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            Question {currentIndex + 1} of {quizzes.length}
          </span>
          {showFeedback && (
            <span
              className={`font-medium ${
                currentQuiz.userAnswer === currentQuiz.correctAnswer
                  ? 'text-green-600 dark:text-green-400'
                  : 'text-red-600 dark:text-red-400'
              }`}
            >
              {currentQuiz.userAnswer === currentQuiz.correctAnswer
                ? '¡Correcto!'
                : '¡Incorrecto!'}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}