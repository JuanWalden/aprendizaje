import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '../../store/useAppStore';
import { ChevronLeft, ChevronRight, RotateCw } from 'lucide-react';

export function Flashcards() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const { flashcards, updateFlashcard } = useAppStore();

  const currentCard = flashcards[currentIndex];

  const handleNext = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev + 1) % flashcards.length);
  };

  const handlePrevious = () => {
    setIsFlipped(false);
    setCurrentIndex((prev) => (prev - 1 + flashcards.length) % flashcards.length);
  };

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const handleStatus = (status: 'new' | 'learning' | 'mastered') => {
    if (currentCard) {
      updateFlashcard(currentCard.id, { status, lastReviewed: new Date() });
      handleNext();
    }
  };

  if (!flashcards.length) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600 dark:text-gray-400">
          No hay tarjetas disponibles. ¡Añade contenido para generar tarjetas de estudio!
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-8">
      <div className="relative h-64">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex + (isFlipped ? '-flipped' : '')}
            initial={{ rotateY: isFlipped ? 180 : 0 }}
            animate={{ rotateY: isFlipped ? 180 : 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="w-full h-full"
            onClick={handleFlip}
          >
            <div
              className={`w-full h-full bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 cursor-pointer
                ${isFlipped ? 'transform rotate-y-180' : ''}`}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  Tarjeta {currentIndex + 1} de {flashcards.length}
                </span>
                <span
                  className={`px-2 py-1 rounded text-sm ${
                    currentCard.status === 'mastered'
                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                      : currentCard.status === 'learning'
                      ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                      : 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                  }`}
                >
                  {currentCard.status === 'mastered' ? 'Dominado' : 
                   currentCard.status === 'learning' ? 'Aprendiendo' : 'Nuevo'}
                </span>
              </div>
              <div className="text-center text-xl font-medium">
                {isFlipped ? currentCard.back : currentCard.front}
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex justify-between items-center mt-8">
        <button
          onClick={handlePrevious}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          <ChevronLeft className="h-6 w-6" />
        </button>

        <div className="flex space-x-2">
          <button
            onClick={() => handleStatus('new')}
            className="px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600"
          >
            Repasar
          </button>
          <button
            onClick={() => handleStatus('learning')}
            className="px-4 py-2 rounded-lg bg-yellow-500 text-white hover:bg-yellow-600"
          >
            Aprendiendo
          </button>
          <button
            onClick={() => handleStatus('mastered')}
            className="px-4 py-2 rounded-lg bg-green-500 text-white hover:bg-green-600"
          >
            Dominado
          </button>
        </div>

        <button
          onClick={handleNext}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          <ChevronRight className="h-6 w-6" />
        </button>
      </div>
    </div>
  );
}