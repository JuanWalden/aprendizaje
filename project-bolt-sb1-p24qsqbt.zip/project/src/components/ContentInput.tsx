import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { FileText, Upload } from 'lucide-react';
import { useAppStore } from '../store/useAppStore';

export function ContentInput() {
  const [wordCount, setWordCount] = useState(0);
  const { content, setContent } = useAppStore();
  const [uploadStatus, setUploadStatus] = useState('');

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    try {
      for (const file of acceptedFiles) {
        const text = await file.text();
        setContent((prevContent) => {
          const newContent = prevContent ? `${prevContent}\n\n${text}` : text;
          setWordCount(newContent.trim().split(/\s+/).length);
          return newContent;
        });
      }
      setUploadStatus('¡Archivos cargados con éxito!');
      setTimeout(() => setUploadStatus(''), 3000);
    } catch (error) {
      setUploadStatus('Error al cargar los archivos. Inténtalo de nuevo.');
      setTimeout(() => setUploadStatus(''), 3000);
    }
  }, [setContent]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/plain': ['.txt'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc', '.docx'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.ms-powerpoint': ['.ppt'],
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx']
    },
    maxSize: 25 * 1024 * 1024, // 25MB
  });

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value;
    setContent(text);
    setWordCount(text.trim().split(/\s+/).length);
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <textarea
          value={content}
          onChange={handleTextChange}
          className="w-full h-48 p-4 border rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:border-gray-600 dark:text-white"
          placeholder="Introduce tu contenido aquí..."
        />
        <div className="absolute bottom-2 right-2 text-sm text-gray-500 dark:text-gray-400">
          {wordCount} palabras
        </div>
      </div>

      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
          isDragActive 
            ? 'border-blue-500 bg-blue-50 dark:border-blue-400 dark:bg-blue-900/30' 
            : 'border-gray-300 dark:border-gray-600'
        }`}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center space-y-2">
          {isDragActive ? (
            <Upload className="h-8 w-8 text-blue-500 dark:text-blue-400" />
          ) : (
            <FileText className="h-8 w-8 text-gray-400 dark:text-gray-500" />
          )}
          <p className="text-sm text-gray-600 dark:text-gray-300">
            Arrastra y suelta archivos aquí, o haz clic para seleccionar
          </p>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Formatos soportados: TXT, PDF, DOC/DOCX, PPT/PPTX (Máximo 25MB)
          </p>
        </div>
      </div>

      {uploadStatus && (
        <div className={`text-center p-2 rounded ${
          uploadStatus.includes('éxito') 
            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
            : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
        }`}>
          {uploadStatus}
        </div>
      )}

      <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg">
        <h3 className="text-lg font-semibold mb-2 text-blue-800 dark:text-blue-300">
          Instrucciones de uso:
        </h3>
        <ul className="list-disc list-inside space-y-2 text-blue-700 dark:text-blue-200">
          <li>Escribe directamente en el área de texto o arrastra archivos para comenzar</li>
          <li>El contenido se procesará automáticamente para crear tarjetas de estudio y cuestionarios</li>
          <li>Utiliza la pestaña "Flashcards" para practicar con tarjetas de memoria</li>
          <li>Accede a "Quiz" para poner a prueba tu conocimiento</li>
          <li>Revisa tu progreso en la pestaña "Progress"</li>
          <li>Personaliza la aplicación en "Settings"</li>
        </ul>
      </div>
    </div>
  );
}