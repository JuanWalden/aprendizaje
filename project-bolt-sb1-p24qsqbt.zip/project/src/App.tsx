import React from 'react';
import { ThemeToggle } from './components/ui/ThemeToggle';
import { ContentInput } from './components/ContentInput';
import { Flashcards } from './components/activities/Flashcards';
import { Quiz } from './components/activities/Quiz';
import { ProgressDashboard } from './components/ProgressDashboard';
import { Settings } from './components/Settings';
import { useAppStore } from './store/useAppStore';
import { BookOpen, Layout, Settings as SettingsIcon } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@radix-ui/react-tabs';

function App() {
  const isDarkMode = useAppStore((state) => state.isDarkMode);

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
      <nav className="border-b bg-white dark:bg-gray-800 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              <span className="text-xl font-semibold text-gray-900 dark:text-white">
                LearnFlow
              </span>
            </div>
            <ThemeToggle />
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="content" className="space-y-6">
          <TabsList className="flex space-x-2 bg-white dark:bg-gray-800 p-1 rounded-lg">
            <TabsTrigger
              value="content"
              className="flex items-center space-x-2 px-4 py-2 rounded-md data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-blue-900 dark:data-[state=active]:text-blue-100"
            >
              <Layout className="h-4 w-4" />
              <span>Content</span>
            </TabsTrigger>
            <TabsTrigger
              value="flashcards"
              className="flex items-center space-x-2 px-4 py-2 rounded-md data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-blue-900 dark:data-[state=active]:text-blue-100"
            >
              <Layout className="h-4 w-4" />
              <span>Flashcards</span>
            </TabsTrigger>
            <TabsTrigger
              value="quiz"
              className="flex items-center space-x-2 px-4 py-2 rounded-md data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-blue-900 dark:data-[state=active]:text-blue-100"
            >
              <Layout className="h-4 w-4" />
              <span>Quiz</span>
            </TabsTrigger>
            <TabsTrigger
              value="progress"
              className="flex items-center space-x-2 px-4 py-2 rounded-md data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-blue-900 dark:data-[state=active]:text-blue-100"
            >
              <Layout className="h-4 w-4" />
              <span>Progress</span>
            </TabsTrigger>
            <TabsTrigger
              value="settings"
              className="flex items-center space-x-2 px-4 py-2 rounded-md data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-blue-900 dark:data-[state=active]:text-blue-100"
            >
              <SettingsIcon className="h-4 w-4" />
              <span>Settings</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="content" className="mt-6">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                Interactive Learning Platform
              </h1>
              <ContentInput />
            </div>
          </TabsContent>

          <TabsContent value="flashcards">
            <Flashcards />
          </TabsContent>

          <TabsContent value="quiz">
            <Quiz />
          </TabsContent>

          <TabsContent value="progress">
            <ProgressDashboard />
          </TabsContent>

          <TabsContent value="settings">
            <Settings />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

export default App;