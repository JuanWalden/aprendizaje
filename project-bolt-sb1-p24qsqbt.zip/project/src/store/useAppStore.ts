import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface Flashcard {
  id: string;
  front: string;
  back: string;
  status: 'new' | 'learning' | 'mastered';
  lastReviewed?: Date;
}

interface Quiz {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  userAnswer?: string;
}

interface Progress {
  flashcardsCompleted: number;
  quizzesCompleted: number;
  totalTimeSpent: number;
  lastSession: Date;
  masteryLevel: number;
}

interface Settings {
  isDarkMode: boolean;
  fontSize: 'small' | 'medium' | 'large';
  highContrast: boolean;
  autoSave: boolean;
  notificationsEnabled: boolean;
}

interface AppState {
  // Theme
  isDarkMode: boolean;
  toggleDarkMode: () => void;

  // Content
  content: string;
  setContent: (content: string) => void;
  contentAnalysis: {
    complexity: number;
    mainTopics: string[];
    language: string;
  } | null;
  setContentAnalysis: (analysis: AppState['contentAnalysis']) => void;

  // Learning Items
  flashcards: Flashcard[];
  addFlashcard: (flashcard: Omit<Flashcard, 'id' | 'status'>) => void;
  updateFlashcard: (id: string, updates: Partial<Flashcard>) => void;
  
  quizzes: Quiz[];
  addQuiz: (quiz: Omit<Quiz, 'id'>) => void;
  updateQuiz: (id: string, updates: Partial<Quiz>) => void;

  // Progress
  progress: Progress;
  updateProgress: (updates: Partial<Progress>) => void;

  // Settings
  settings: Settings;
  updateSettings: (updates: Partial<Settings>) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      // Theme
      isDarkMode: false,
      toggleDarkMode: () => set((state) => ({ isDarkMode: !state.isDarkMode })),

      // Content
      content: '',
      setContent: (content) => set({ content }),
      contentAnalysis: null,
      setContentAnalysis: (analysis) => set({ contentAnalysis: analysis }),

      // Learning Items
      flashcards: [],
      addFlashcard: (flashcard) =>
        set((state) => ({
          flashcards: [
            ...state.flashcards,
            {
              ...flashcard,
              id: crypto.randomUUID(),
              status: 'new',
            },
          ],
        })),
      updateFlashcard: (id, updates) =>
        set((state) => ({
          flashcards: state.flashcards.map((card) =>
            card.id === id ? { ...card, ...updates } : card
          ),
        })),

      quizzes: [],
      addQuiz: (quiz) =>
        set((state) => ({
          quizzes: [...state.quizzes, { ...quiz, id: crypto.randomUUID() }],
        })),
      updateQuiz: (id, updates) =>
        set((state) => ({
          quizzes: state.quizzes.map((quiz) =>
            quiz.id === id ? { ...quiz, ...updates } : quiz
          ),
        })),

      // Progress
      progress: {
        flashcardsCompleted: 0,
        quizzesCompleted: 0,
        totalTimeSpent: 0,
        lastSession: new Date(),
        masteryLevel: 0,
      },
      updateProgress: (updates) =>
        set((state) => ({
          progress: { ...state.progress, ...updates },
        })),

      // Settings
      settings: {
        isDarkMode: false,
        fontSize: 'medium',
        highContrast: false,
        autoSave: true,
        notificationsEnabled: true,
      },
      updateSettings: (updates) =>
        set((state) => ({
          settings: { ...state.settings, ...updates },
        })),
    }),
    {
      name: 'learn-flow-storage',
    }
  )
);